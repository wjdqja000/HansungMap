package com.example.act_mapview;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.MyLocationOverlay;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;
import com.hansungmapservice.activity.LocationDetailActivity;
import com.hansungmapservice.data.LocationDataManager;
import com.hansungmapservice.data.ServerMessage;
import com.hansungmapservice.restful.RequestMethod;
import com.hansungmapservice.restful.RestClient;
import com.hansungmapservice.url.UrlConstants;

public class Act_MapView extends MapActivity {
	MapView mMap;
	MapController mControl;
	MyLocation mLocation;
	public List<Overlay> mapOverlays;
	public Drawable drawable_Red, drawable_Green;
	private EditText edtSearch;
	private RestClient client;
	private AsyncTask<RestClient, Integer, Void> mTask;

	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		mMap = (MapView) findViewById(R.id.map);
		mControl = mMap.getController();

		mMap.setBuiltInZoomControls(true);

		drawable_Red = this.getResources().getDrawable(R.drawable.marker);
		drawable_Red.setBounds(0, 0, drawable_Red.getIntrinsicWidth(),
				drawable_Red.getIntrinsicHeight());

		drawable_Green = this.getResources().getDrawable(R.drawable.marker2);
		drawable_Green.setBounds(0, 0, drawable_Green.getIntrinsicWidth(),
				drawable_Green.getIntrinsicHeight());

		mapOverlays = mMap.getOverlays();

		mLocation = new MyLocation(this, mMap);
		GeoPoint pt = mLocation.getMyLocation();

		mapOverlays.add(mLocation);

		mLocation.runOnFirstFix(new Runnable() {
			public void run() {
				mMap.getController().animateTo(mLocation.getMyLocation());

			}
		});

		mControl.setZoom(20);
		Cus_Marker markOverlays = new Cus_Marker(drawable_Red);
		String data;

		int i;

		OverlayItem overlayItem1 = new OverlayItem(new GeoPoint(37583400,
				127010440), "������", "������");

		OverlayItem overlayItem2 = new OverlayItem(new GeoPoint(37583570,
				127010440), "������", "������");

		overlayItem1.setMarker(drawable_Green);
		overlayItem2.setMarker(drawable_Red);

		markOverlays.addOverlay(overlayItem1);
		markOverlays.addOverlay(overlayItem2);

		mapOverlays.add(markOverlays);

		Button btnSearch = (Button) findViewById(R.id.main_btn_insert);
		edtSearch = (EditText) findViewById(R.id.main_edit_insert);

		client = new RestClient();
		
		btnSearch.setOnClickListener(new View.OnClickListener() {

			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				String location_name = edtSearch.getText().toString();

				if (location_name.length() == 0) {

					Toast.makeText(Act_MapView.this, "�˻�� �Է����ּ���",
							Toast.LENGTH_SHORT).show();
				} else {/*
						 * Intent intent = new Intent(MainActivity.this,
						 * LocationDetailActivity.class);
						 * intent.putExtra("location_name", location_name);
						 * startActivity(new Intent(MainActivity.this,
						 * LocationDetailActivity.class));
						 */

					
					// client.SetUrl("http://hansungmapservice1.appspot.com/send_location?location_name=hansung_store");
					
					mTask = new AsyncTask<RestClient , Integer, Void>(){

						@Override
						protected void onPreExecute(){
							client.SetUrl(UrlConstants.SEARCH_LOCATION);
							String location_name = edtSearch.getText().toString();
							client.AddParam("location_name", location_name);
							
							Log.e("bb", "url : "+client.getURL());
						}
						
						protected Void doInBackground(RestClient... params) {
							// TODO Auto-generated method stub
							
							try {
								//int i =params.length;
								Log.e("bb","try   ");
								client.Execute(RequestMethod.GET);
								
								//params[0].Execute(RequestMethod.GET);
							}
							catch (Exception e) {
								// TODO Auto-generated catch block
								Log.e("bb", "catch");
								Toast.makeText(Act_MapView.this, e.getMessage(),Toast.LENGTH_SHORT).show();
							
							}
								
							
							return null;
						}
						
					};
					
					mTask.execute(client);
					
					
					
					String response = client.getResponse();
					
					Log.e("bb", "here1  "+response+"   "+location_name);
					
					
					if (response != ServerMessage.NO_DATA || response != null) {
						
						
						
						LocationDataManager.getInstance().setLocation_name(location_name);
						
						LocationDataManager.getInstance().dataParsing(response);
						
						Intent intent = new Intent(Act_MapView.this,LocationDetailActivity.class);
						
						startActivity(intent);
						
						
						
					} 
					else {
						
						Toast.makeText(Act_MapView.this, ServerMessage.NO_DATA,Toast.LENGTH_SHORT).show();
										}
					
					client.ClearParam();

				}
			}
		});

	}

	public void onResume() {
		super.onResume();
		mLocation.enableMyLocation();
		mLocation.enableCompass();

	}

	public void onPause() {
		super.onPause();
		mLocation.disableMyLocation();
		mLocation.disableCompass();
	}

	class Cus_Marker extends BalloonItemizedOverlay<OverlayItem> {

		private ArrayList<OverlayItem> m_overlays = new ArrayList<OverlayItem>();
		private Context c;

		public Cus_Marker(Drawable defaultMarker) {
			super(drawable_Red, mMap);
			boundCenterBottom(defaultMarker);
			boundCenterBottom(drawable_Green);
			c = mMap.getContext();
		}

		public void addOverlay(OverlayItem overlay) {
			m_overlays.add((overlay));
			populate();
		}

		@Override
		protected OverlayItem createItem(int i) {
			return m_overlays.get(i);
		}

		@Override
		public int size() {
			return m_overlays.size();
		}

		@Override
		protected boolean onBalloonTap(int index) {

			Log.i("cc", "here1");

			Intent it = new Intent(c, Example01_Move01.class);
			c.startActivity(it);

			// Intent Details = new Intent(c , Example01_Move01.class);
			// Details.putExtra("Id", 1327);
			// ((MapActivity) c).startActivity(Details);

			return true;

		}

	}

	class MyLocation extends MyLocationOverlay {
		public MyLocation(Context context, MapView mapView) {
			super(context, mapView);
			// TODO Auto-generated constructor stub
		}

		protected boolean dispatchTap() {

			return false;

		}

	}
}