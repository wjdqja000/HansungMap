package com.example.act_mapview;

import com.example.act_mapview.Act_MapView;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Example01_Move01 extends Activity {
	
	EditText edt;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		Log.i("cc", "here2");
		super.onCreate(savedInstanceState);
		setContentView(R.layout.example01_move01);

		Log.i("cc", "here3");
		edt = (EditText) findViewById(R.id.editText1);

		/*
		String str_main = getIntent().getStringExtra("str_main");
		if (str_main.length() != 0) {
			edt.setText(str_main);
		}
		 */
		Button btn;
		btn = (Button) findViewById(R.id.button1);
		btn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub


				Intent intent = new Intent(Example01_Move01.this, Act_MapView.class);
				/*
				String value = edt.getText().toString();
				intent.putExtra("jmlee", value);
				//�޴� �ʿ��� ��� ��Ƽ��Ƽ���� ���� �Ѿ�Դ��� �����ϱ� �����̴�.
				Example01_Move01.this.setResult(777,  intent);
				
				
				*/
				
				startActivity(intent);
				finish();

			}
		});
		// TODO Auto-generated method stub
		
		
	}

}
