package com.example.act_mapview;

import com.example.act_mapview.Example01_Move01;
import com.google.android.maps.OverlayItem;
import android.content.Context;
import android.content.Intent;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class BalloonOverlayView extends FrameLayout {

 
 private LinearLayout layout;
 private TextView title;
 private TextView snippet;
 protected int  DeviceNum;
 protected  int balloonBottomOffset = 18;   // ��ǳ�� ��ġ Offset  Marker ũ�⿡ ���� ������ �������ּ���
 public BalloonOverlayView(Context context) {
  super(context);
  
  // TODO Auto-generated constructor stub
  setPadding(10, 0,10, balloonBottomOffset);
  layout = new LinearLayout(context);
  layout.setVisibility(VISIBLE);
  LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
  View v = inflater.inflate(R.layout.balloonoverlay, layout);
  title = (TextView)v.findViewById(R.id.balloon_item_title);
  snippet = (TextView)v.findViewById(R.id.balloon_item_snippet);
  ImageView pt = (ImageView) v.findViewById(R.id.close_img_button);
  ImageView close = (ImageView) v.findViewById(R.id.close_img_button);

  close.setOnClickListener(new OnClickListener(){     // ��ǳ�� ���� ��ư Ŭ����
   public void onClick(View v){
    BallroonClose();
}
  });
  
  
  
  
  
  FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
  params.gravity = Gravity.NO_GRAVITY;
  addView(layout, params);
 }
 public void BallroonClose()
 {
  layout.setVisibility(GONE);
 }
 public void setData(OverlayItem item){    // ��ǳ���� ǥ�� �� ���� �ִ°�
  layout.setVisibility(VISIBLE);
  if(item.getTitle() != null){
   title.setVisibility(VISIBLE);   
   title.setText(item.getTitle());   
  } else{
   title.setVisibility(GONE);
  }
  if(item.getSnippet() != null){
   snippet.setVisibility(VISIBLE);
   snippet.setText(item.getSnippet());
  } else{
   snippet.setVisibility(GONE);
  }
 }
}