package com.example.act_mapview;

import java.lang.reflect.Method;
import java.util.List;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;
public abstract class BalloonItemizedOverlay<ITEM> extends ItemizedOverlay<OverlayItem> {
 private MapView mapView;
 public  static BalloonOverlayView balloonView = null;
 private View clickRegion;
 protected int viewOffset;
 
 final MapController mc;
 
 public BalloonItemizedOverlay(Drawable defaultMarker, MapView mapView) {
  super(defaultMarker);
  // TODO Auto-generated constructor stub
  this.mapView = mapView;
  viewOffset = 18;
  mc = mapView.getController();
      
 }
 
 public void draw(android.graphics.Canvas canvas,
            MapView mapView,
            boolean shadow){
  
  super.draw(canvas, mapView, false);
  
 }
 
 public void setBalloonBootomOffset(int pixels){
  viewOffset = pixels;
  
 }
 
 @Override
 protected final boolean onTap(int index){
  
  boolean isRecycled;
  final int thisIndex;
  GeoPoint point;
  
  thisIndex = index;
  point = createItem(index).getPoint();
  
  
  if(balloonView == null){
   balloonView = new BalloonOverlayView(mapView.getContext());
   clickRegion = (View)balloonView.findViewById(R.id.balloon_inner_layout);
   isRecycled = false;
  } else {
   isRecycled = true;
   
  }
  
  balloonView.setVisibility(View.GONE);
    
  balloonView.setData(createItem(index));
  
  MapView.LayoutParams params = new MapView.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, point, MapView.LayoutParams.BOTTOM_CENTER);
  params.mode = MapView.LayoutParams.MODE_MAP;
  
  
  
//  balloonView.setVisibility(View.VISIBLE);2
  
  
  if(isRecycled){
   balloonView.setLayoutParams(params);
   
   balloonView.setVisibility(View.VISIBLE);
  } else {
   setBalloonTouchListener(index);
   balloonView.setVisibility(View.VISIBLE);
   mapView.addView(balloonView, params);
   mc.animateTo(point);
   
  }

 return true;
  
 }
   
 private void setBalloonTouchListener(final int thisIndex){
  try{
   @SuppressWarnings("unused")
   Method m = this.getClass().getDeclaredMethod("onBalloonTap", int.class);
  
   clickRegion.setOnTouchListener(new OnTouchListener(){
    public boolean onTouch(View v, MotionEvent event){
     
     View l = ((View)v.getParent()).findViewById(R.id.balloon_main_layout);
     Drawable d = l.getBackground();
     
     if(event.getAction() == MotionEvent.ACTION_DOWN){
      int[] states = {android.R.attr.state_pressed};
      if(d.setState(states)){
       d.invalidateSelf();
      }
      return true;
      
     } else if (event.getAction() == MotionEvent.ACTION_UP){
      int newStates[] = {};
      if(d.setState(newStates)){
       d.invalidateSelf();
      }
      onBalloonTap(thisIndex);
      
      
      
      return true;
     }else {
      return false;
     }
    }
   });
  } catch (SecurityException e){
   Log.d("seuny", "setBalloonTouchListener reflection SecurityException");
   return;
  }catch (NoSuchMethodException e){
   return;
  }
 }
 protected boolean onBalloonTap(int index) {
  // TODO Auto-generated method stub
  return false;
 }
 
}