package com.hansungmapservice.activity;

import java.io.BufferedInputStream;
import java.net.URL;
import java.net.URLConnection;

import com.hansungmapservice.data.LocationDataManager;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class LocationDetailActivity extends Activity {

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(com.example.act_mapview.R.layout.test_layout);

		TextView txtView = (TextView) findViewById(com.example.act_mapview.R.id.textView1);
		ImageView imgView = (ImageView) findViewById(com.example.act_mapview.R.id.imageView1);

		String test_tmp = "";
		test_tmp += "�̸� : "
				+ LocationDataManager.getInstance().getLocation_name() + "\n";
		test_tmp += "���� : "
				+ LocationDataManager.getInstance().getLocation_latitude()
				+ "\n";
		test_tmp += "�浵 : "
				+ LocationDataManager.getInstance().getLocation_longitude()
				+ "\n";
		test_tmp += "�̹���:"
				+ LocationDataManager.getInstance().getLocation_image() + "\n";

		txtView.setText(test_tmp);

		// url�� �̹��� �׷��ִ� �ڵ�
		Bitmap bm = GetImageFromURL(LocationDataManager.getInstance()
				.getLocation_image());
		if (bm != null) {
			imgView.setImageBitmap(bm);
		} else {
			imgView.setImageResource(com.example.act_mapview.R.drawable.noimage);
		}

		// TODO Auto-generated method stub
	}

	private Bitmap GetImageFromURL(String strImageURL) {
		Bitmap imgBitmap = null;
		try {
			URL url = new URL(strImageURL);
			URLConnection conn = url.openConnection();
			conn.connect();
			int nSize = conn.getContentLength();
			BufferedInputStream bis = new BufferedInputStream(
					conn.getInputStream(), nSize);
			imgBitmap = BitmapFactory.decodeStream(bis);
			bis.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return imgBitmap;
	}
}
