package com.hansungmapservice.data;

/*
 * Server Constants position is DataParser class.
 * 	public static final char LOCATION_NAME = '0';
 public static final char LOCATION_LATITUDE = '1';
 public static final char LOCATION_LONGITUDE = '2';
 public static final char LOCATION_IMAGE = '3';	

 * 
 */

import java.util.HashMap;
import java.util.List;

import android.util.Log;

/*
 ��ġ ������ �����ͼ� �����ϴ� Ŭ����
 �����ڷ� : �̱��� ����.
 */
public class LocationDataManager {
	private static LocationDataManager instance = null;

	public static LocationDataManager getInstance() {
		if (instance != null)
			return instance;

		synchronized (LocationDataManager.class) {
			if (instance == null) {
				instance = new LocationDataManager();
			}
		}
		return instance;
	}

	// ���� ������
	private String location_name; // �̸�
	private String location_latitude; // ����
	private String location_longitude; // �浵
	private String location_image; // �̹���

	// ���� ������
	private List<String> location_names;
	private HashMap<String, String> location_latitdes; // key = location_name;
	private HashMap<String, String> location_longitudes;// key = location_name;

	public LocationDataManager() {
		// TODO Auto-generated constructor stub
	}

	public void dataParsing(String data) {
		DataParser data_parser = new DataParser(data);
		data_parser.Execute();
		location_latitude = data_parser.getLocationLatitude();
		location_longitude = data_parser.getLocationLongitude();
		location_image = data_parser.getLocation_image();
	} 

	public String getLocation_name() {
		return location_name;
	}

	public void setLocation_name(String location_name) {
		this.location_name = location_name;
	}

	public String getLocation_latitude() {
		return location_latitude;
	}

	public void setLocation_latitude(String location_latitude) {
		this.location_latitude = location_latitude;
	}

	public String getLocation_longitude() {
		return location_longitude;
	}

	public void setLocation_longitude(String location_longitude) {
		this.location_longitude = location_longitude;
	}

	public String getLocation_image() {
		return location_image;
	}

	public void setLocation_image(String location_ImageUrl) {
		this.location_image = location_ImageUrl;
	}

	public List<String> getLocation_names() {
		return location_names;
	}

	public void setLocation_names(List<String> location_names) {
		this.location_names = location_names;
	}

	public HashMap<String, String> getLocation_latitdes() {
		return location_latitdes;
	}

	public void setLocation_latitdes(HashMap<String, String> location_latitdes) {
		this.location_latitdes = location_latitdes;
	}

	public HashMap<String, String> getLocation_longitudes() {
		return location_longitudes;
	}

	public void setLocation_longitudes(
			HashMap<String, String> location_longitudes) {
		this.location_longitudes = location_longitudes;
	}

}

class DataParser {

	public static final char LOCATION_NAME = '0';
	public static final char LOCATION_LATITUDE = '1';
	public static final char LOCATION_LONGITUDE = '2';
	public static final char LOCATION_IMAGE = '3';

	private String data;
	private int index;

	private String location_name;
	private String location_latitude;
	private String location_longitude;
	private String location_image;

	public DataParser(String data) {
		// TODO Auto-generated constructor stub
		this.data = data;
	}

	/* ��ġ �̸� */
	public String getLocationName() {
		return location_name;
	}

	/* ���� */
	public String getLocationLatitude() {
		return location_latitude;
	}

	/* �浵 */
	public String getLocationLongitude() {
		return location_longitude;
	}

	/* �̹��� */
	public String getLocation_image() {
		return location_image;
	}

	public void Execute() {

		for (index = 0; index < data.length(); index++) {
			Log.i("check", "index : " + index);
			switch (data.charAt(index)) {
			case LOCATION_LATITUDE:
				// ����.
				location_latitude = Excute_Process();
				break;

			case LOCATION_LONGITUDE:
				location_longitude = Excute_Process();
				break;

			case LOCATION_IMAGE:
				location_image = Excute_Process();
				break;

			case ';':
				break;

			default:
				Log.i("dataParser", "server data is incorrect!! error!!");
				break;
			}
		}

	}

	private String Excute_Process() {
		StringBuffer temp = new StringBuffer();
		index += 2;
		while ((data.charAt(index) != ',')) {
			temp.append(data.charAt(index));
			index++;
			if (index >= (data.length()-1) || data.charAt(index) == ';') {
				break;
			}

		}
		if (temp.length() == 0) {
			return "no data";
		}

		return temp.toString();
	}

}
