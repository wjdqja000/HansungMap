package com.hansungmapservice.data;

public class ServerMessage {
	public static final String NO_DATA = "no data";
}
