package com.hansungmapservice.url;

public class UrlConstants {
	
	public static final String SEARCH_LOCATION = "http://hansungmapservice1.appspot.com/send_location";
}
