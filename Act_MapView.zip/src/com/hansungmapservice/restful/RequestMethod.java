package com.hansungmapservice.restful;

public enum RequestMethod {
    GET,
    POST
}
