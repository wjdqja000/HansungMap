package com.hansungmapservice.restful;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;

import com.example.act_mapview.Act_MapView;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

public class RestClient 
{
    private ArrayList<NameValuePair> params;
    private ArrayList<NameValuePair> headers;
    private String url;
    private static AsyncTask<Void, String, Void> mTask;
    private int responseCode;
    private String message;
 
    private String response;
 
    public String getResponse()
    {
        return response;
    }
 
    public String getErrorMessage()
    {
        return message;
    }
 
    public int getResponseCode()
    {
        return responseCode;
    }
 
    public RestClient() {

        params = new ArrayList<NameValuePair>();
        headers = new ArrayList<NameValuePair>();
    }
    
    public void SetUrl(String url){
    	this.url = url;
    	    	
    }
    public String getURL(){
    	return this.url;
    }
 
    public void AddParam(String name, String value)
    {
        params.add(new BasicNameValuePair(name, value));
       
    }
    
    
    public void ClearParam()
    {
    	params.clear();
    }
 
    public void AddHeader(String name, String value)
    {
        headers.add(new BasicNameValuePair(name, value));
    }
 
    public void Execute(RequestMethod method) throws Exception
    {
    	switch (method)
        {
        case GET:
        {
            // add parameters
            String combinedParams = "";
            if (!params.isEmpty())
            {
                combinedParams += "?";
                for (NameValuePair p : params)
                {
                    String paramString = p.getName() + "=" + URLEncoder.encode(p.getValue(),"UTF-8");
                    if (combinedParams.length() > 1)
                    {
                        combinedParams += "&" + paramString;
                    }
                    else
                    {
                        combinedParams += paramString;
                    }
                }
            }
 
            HttpGet request = new HttpGet(url + combinedParams);
 
            // add headers
            for (NameValuePair h : headers)
            {
                request.addHeader(h.getName(), h.getValue());
            }
            //Log.e("cc", "request : "+request);
            executeRequest(request, url);
            
            break;
        }
        case POST:
        {
            HttpPost request = new HttpPost(url);
 
            // add headers
            for (NameValuePair h : headers)
            {
                request.addHeader(h.getName(), h.getValue());
            }
 
            if (!params.isEmpty())
            {
                request.setEntity(new UrlEncodedFormEntity(params, HTTP.UTF_8));
            }
 
            executeRequest(request, url);
            break;
        }
        }
        //Log.e("cc", "method : "+method);
    }
 
    private void executeRequest(HttpUriRequest request, String url)
    {
    	HttpClient client = new DefaultHttpClient();
        //Log.e("cc", "here1 "+client);
        //Log.e("cc", "here111 "+request);
        HttpResponse httpResponse;
      
        try
        {
		 	
        	Log.e("cc", "here11  ");
            httpResponse = client.execute(request);
            Log.e("cc", "here12   "+httpResponse);
            responseCode = httpResponse.getStatusLine().getStatusCode();
            Log.e("cc", "here13   "+responseCode);
            message = httpResponse.getStatusLine().getReasonPhrase();
            Log.e("cc", "here14  "+message);
            HttpEntity entity = httpResponse.getEntity();
            Log.e("cc", "here15  "+entity);
            
            
            
            if (entity != null)
            {
 
            	Log.e("cc", "here16  ");
                InputStream instream = entity.getContent();
                Log.e("cc", "here17  "+instream);
                response = convertStreamToString(instream);
                Log.e("cc", "here18  "+response);
                instream.close();
            }
 
        }
        catch (ClientProtocolException e)
        {
        	Log.e("cc", "here3  ");
        	client.getConnectionManager().shutdown();
           
            e.printStackTrace();
        }
        catch (IOException e)
        {
        	Log.e("cc", "here4  ");
        	client.getConnectionManager().shutdown();
            e.printStackTrace();
        }
       
        
    }
 
    private static String convertStreamToString(InputStream is)
    {
    	
    	InputStream a=is;
    	BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        Log.e("cc", "here19  "+reader);
        StringBuilder sb = new StringBuilder();
    	
       
 
        String line = null;
        try
        {
            while ((line = reader.readLine()) != null)
            {
            	Log.e("cc", "here20  "+line);
                sb.append(line + "\n");
                Log.e("cc", "here21  "+sb);
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        
        
        
        
        
        finally
        {
            try
            {
                is.close();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
        
        
        return sb.toString();
    }

	
}